package com.example.xworldanalyzer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val requestCapture = 4102
    private lateinit var status: TextView
    private lateinit var recognized: TextView
    private lateinit var stats: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            val p = getSharedPreferences("xworld", Context.MODE_PRIVATE)
            status.text = if (p.getBoolean("running", false)) "Đang đọc màn hình" else "Chưa đọc màn hình"
            recognized.text = p.getString("ocr", "Chưa có nội dung nhận diện")
            val w = p.getInt("wins", 0); val l = p.getInt("losses", 0); val total = w + l
            val rate = if (total == 0) 0.0 else w * 100.0 / total
            stats.text = "Thắng: $w    Thua: $l    Tổng: $total\nTỷ lệ thắng ghi nhận: ${"%.1f".format(rate)}%"
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 32, 28, 24); gravity = Gravity.TOP }
        fun label(s: String, size: Float = 16f) = TextView(this).apply { text = s; textSize = size; setPadding(0, 10, 0, 10) }
        root.addView(label("X WORLD – VUA THOÁT HIỂM", 22f))
        status = label("Chưa đọc màn hình", 18f); root.addView(status)
        val start = Button(this).apply { text = "Bắt đầu đọc màn hình"; setOnClickListener {
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mgr.createScreenCaptureIntent(), requestCapture)
        } }; root.addView(start)
        val stop = Button(this).apply { text = "Dừng đọc màn hình"; setOnClickListener { stopService(Intent(this@MainActivity, CaptureService::class.java)); getSharedPreferences("xworld", 0).edit().putBoolean("running", false).apply() } }; root.addView(stop)
        root.addView(label("Nội dung nhận diện (OCR):", 17f))
        recognized = label("Chưa có nội dung nhận diện"); recognized.textSize = 14f; root.addView(recognized)
        root.addView(label("Kết quả do bạn xác nhận:", 17f))
        val wins = Button(this).apply { text = "Ghi nhận THẮNG"; setOnClickListener { val p = getSharedPreferences("xworld", 0); p.edit().putInt("wins", p.getInt("wins", 0) + 1).apply() } }; root.addView(wins)
        val losses = Button(this).apply { text = "Ghi nhận THUA"; setOnClickListener { val p = getSharedPreferences("xworld", 0); p.edit().putInt("losses", p.getInt("losses", 0) + 1).apply() } }; root.addView(losses)
        val reset = Button(this).apply { text = "Xóa thống kê"; setOnClickListener { getSharedPreferences("xworld", 0).edit().putInt("wins", 0).putInt("losses", 0).apply() } }; root.addView(reset)
        stats = label("Thắng: 0    Thua: 0    Tổng: 0\nTỷ lệ thắng ghi nhận: 0%", 16f); root.addView(stats)
        root.addView(label("Chỉ thống kê dữ liệu đã ghi nhận; không dự đoán chắc chắn kết quả ván tiếp theo và không tự đặt cược.", 12f))
        setContentView(root)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java).putExtra("resultCode", resultCode).putExtra("data", data)
            startForegroundService(i)
        }
    }

    override fun onResume() { super.onResume(); handler.post(refresh) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(refresh) }
}
